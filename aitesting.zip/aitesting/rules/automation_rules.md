# Automation Rules and Standards for Python Playwright MCP

These rules must be followed for all generated automation code.

---

## 1. Framework Structure
- Use Python Playwright (sync mode).
- Use pytest for all test execution.
- Store all Page Object Model (POM) classes inside `aitesting/page_objects/`.
- Store generated test files inside `aitesting/tests/`.
- Every test case must have its own pytest function starting with `test_` and include the test case ID (e.g., `test_US_ATC_02_TC_001()`).

---

## 2. Page Object Model (POM) Standards
Each POM class must include:

1. A constructor accepting the Playwright `page`.
2. All locators declared as class-level attributes.
3. Modular methods for:
   - Navigation (open pages, load product detail pages).
   - Element actions (click, fill, add to cart).
   - Validation (text, prices, quantities, cart count).
4. Selector Rules:
   - Prefer `data-*` attributes or accessibility-based selectors.
   - No hardcoded brittle CSS/XPath.
   - Every selector must be MCP-validated.

---

## 3. Coding Standards
- Do not use `time.sleep`.
- Use Playwright `expect()` for waits and validation.
- Use descriptive method names.
- No inline hardcoded waits or manual sleep.
- All reusable logic must be inside POM classes, not test files.
- All steps must log actions using Python logging.
- On failure, screenshots must be saved to `aitesting/logs/screenshots/`.

---

## 4. MCP Usage Requirements
All code generation must actively use Playwright MCP:

- Open base URL from `aitesting/config/env.py`.
- Inspect elements.
- Discover selectors.
- Validate each selector before adding to the POM.
- Re-run failing steps while validating interactions.
- If a selector breaks:
  - Rediscover a working selector with MCP.
  - Fix the POM automatically.
  - Retry the step.

This guarantees fully stable tests.

---

## 5. Test Generation Rules
For each test case in `aitesting/testcases/manualtestcases.md`:

- Generate a pytest test function.
- Use POM classes for all steps.
- Extract all dynamic values from:
  - Users in `aitesting/config/env.py`
  - Products/SKUs/prices in `aitesting/config/env.py`
---

## 6. Output Requirements
The MCP must produce:

1. All required POM classes inside `aitesting/page_objects/`.
2. One generated test file:  
   `aitesting/tests/test_generated.py`
3. All selectors must be MCP-verified.
4. All tests must run **without modification**.
5. Each test must include:
   - Logging for each step.
   - Screenshots on failure.

---

## 7. Data Usage Requirements
- Never hardcode usernames, passwords, SKUs, or prices.
- All dynamic values must be loaded from `aitesting/config/env.py`.
- Tests must remain fully environment-driven.

---

## 8. Forbidden Actions
- Do NOT modify existing POM classes unless MCP detects a selector failure.
- Do NOT generate code unrelated to defined manual test cases.
- Do NOT bypass MCP selector validation at any point.
- Do NOT use unvalidated CSS/XPath.